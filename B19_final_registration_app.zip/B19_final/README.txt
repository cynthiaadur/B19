B19 — Class of 2019 Get Together
FINAL REGISTRATION APP

Event
Date: 26 December 2026
Venue: Zegans Hotel, Lira
Time: 10:00 AM onwards

This app is connected to the B19 Supabase database and is ready for RSVP registration.

How to use
1. Extract this ZIP.
2. Open index.html in a browser.
3. Use the RSVP tab to register.
4. Successful registrations are stored online in Supabase.

Organizer data
For privacy, attendee records are not displayed publicly in the app. Organizers can view and export them from:
Supabase Dashboard → Table Editor → registrations

Important security note
The browser uses a Supabase publishable key. Do NOT replace it with a Supabase secret/service-role key.
