-- B19 registrations table
-- Run this only if the table does not already exist.

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null,
  email text,
  guests integer not null default 1,
  message text,
  created_at timestamptz not null default now(),
  attending boolean not null default true,
  note text
);

alter table public.registrations enable row level security;

-- Allow the public RSVP form to create registrations.
drop policy if exists "Anyone can register for B19" on public.registrations;
create policy "Anyone can register for B19"
on public.registrations
for insert
to anon
with check (true);

-- Do not add a public SELECT policy. Organizer data should remain private.
